// にゃんカロ service worker
// アプリ本体はキャッシュしてオフラインでも起動できるようにする。
// 更新したら VERSION の数字を上げると、利用者のスマホに新しい版が届く。
const VERSION = 'v8';
const CACHE = 'nekocal-' + VERSION;
const APP_FILES = [
  './',
  './index.html',
  './manifest.webmanifest',
  './style.css',
  './data.js',
  './cat.js',
  './petcat.js',
  './petcat.css',
  './sagase.html',
  './sagase.css',
  './home-bg.jpg',
  './cats/tabby-body.png',
  './cats/tabby-tail.png',
  './cats/tabby-shirt.png',
  './cats/tabby-gloves.png',
  './cats/white-body.png',
  './cats/white-tail.png',
  './cats/white-shirt.png',
  './cats/white-gloves.png',
  './cats/longwhite-body.png',
  './cats/longwhite-tail.png',
  './cats/longwhite-shirt.png',
  './cats/longwhite-gloves.png',
  './cats/grey-body.png',
  './cats/grey-tail.png',
  './cats/grey-shirt.png',
  './cats/grey-gloves.png',
  './gym-bg.jpg',
  './shop-bg.jpg',
  './app.js',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './apple-touch-icon.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(APP_FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('nekocal-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // 画面（HTML）：ネット優先、つながらなければキャッシュ
  // （ミニゲームの sagase.html も画面なので、ページごとに別々に保存する）
  if (req.mode === 'navigate') {
    const isGame = url.pathname.endsWith('/sagase.html');
    const key = isGame ? './sagase.html' : './index.html';
    e.respondWith(
      fetch(req)
        .then((res) => { if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(key, copy)); } return res; })
        .catch(() => caches.match(key))
    );
    return;
  }

  // Google Fonts：キャッシュがあればすぐ使い、裏で更新
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    e.respondWith(
      caches.open(CACHE).then((c) =>
        c.match(req).then((hit) => {
          const net = fetch(req).then((res) => { c.put(req, res.clone()); return res; }).catch(() => hit);
          return hit || net;
        })
      )
    );
    return;
  }

  // それ以外の自分のファイル：キャッシュ優先
  if (url.origin === location.origin) {
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req)));
  }
});
